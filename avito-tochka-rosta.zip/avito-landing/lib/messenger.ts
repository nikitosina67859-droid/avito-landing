import { siteConfig } from "./config";
import { trackEvent } from "./analytics";

// Открывает личные сообщения. Если ссылка поддерживает параметр текста —
// добавляем его; если нет (или переход не сработал) — копируем текст
// в буфер обмена, чтобы человек мог сразу вставить его в чат.
export async function openMessenger(customMessage?: string) {
  const message = customMessage || siteConfig.prefilledMessage;

  try {
    await navigator.clipboard.writeText(message);
  } catch {
    // буфер обмена недоступен — не критично, просто откроем ссылку
  }

  trackEvent("messenger_open");

  if (
    siteConfig.messengerLink &&
    !siteConfig.messengerLink.startsWith("ВСТАВИТЬ")
  ) {
    window.open(siteConfig.messengerLink, "_blank", "noopener,noreferrer");
  } else {
    // eslint-disable-next-line no-console
    console.warn(
      "[messenger] Укажите ссылку на личные сообщения в lib/config.ts (siteConfig.messengerLink)"
    );
  }
}
