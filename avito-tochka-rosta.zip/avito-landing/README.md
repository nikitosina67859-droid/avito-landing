# Точка роста — лендинг для авитолога (строительная ниша)

Next.js 14 + TypeScript + Tailwind CSS + Framer Motion + Lucide Icons.

## 1. Запуск локально

Нужен установленный Node.js 18+ и доступ в интернет (для установки пакетов).

```bash
npm install
npm run dev
```

Сайт откроется на http://localhost:3000

Сборка для продакшена:

```bash
npm run build
npm run start
```

## 2. Что обязательно нужно поменять перед запуском

Все редактируемые данные собраны в одном файле — **`lib/config.ts`**:

| Что | Где |
|---|---|
| Ссылка на личные сообщения (ВК/Telegram/Max) | `siteConfig.messengerLink` |
| Текст автоподстановки в сообщении | `siteConfig.prefilledMessage` |
| ID Яндекс Метрики | `siteConfig.analytics.yandexMetrikaId` |
| ID VK Pixel (Retargeting ID) | `siteConfig.analytics.vkPixelId` |
| Заголовок / описание для SEO | `siteConfig.seo` |
| Реальный домен сайта | `siteConfig.seo.url` |
| Кейсы (сейчас заглушки!) | массив `cases` |
| Вопросы FAQ | массив `faqItems` |

⚠️ **Кейсы в `cases` — временные данные-заглушки.** Перед запуском рекламы замените их на подтверждённые цифры (или уберите блок, если кейсов пока нет).

## 3. Замена фотографий

Фото специалиста лежит в `public/images/nikita.jpg` (уже подставлено ваше фото, обрезка убрана — используется `object-fit: contain`, так что при замене фото само подстроится под контейнер и не обрежется).

Чтобы заменить:
1. Положите новый файл в `public/images/` (лучше .jpg/.webp, ширина от 800px).
2. Пропишите путь в `lib/config.ts` → `siteConfig.images.heroSpecialist` и `siteConfig.images.aboutSpecialist`.

Все декоративные элементы (деньги, монеты, график, уведомления) — это SVG/CSS, а не фотографии, поэтому они не требуют замены и всегда рендерятся чётко на любом экране.

## 4. Аналитика

Компонент `components/AnalyticsInit.tsx` автоматически:
- сохраняет UTM-метки из ссылки в `localStorage` (`lib/analytics.ts → captureUtm`);
- подключает Яндекс Метрику и VK Pixel, если вы вставили реальные ID в `lib/config.ts` (пока там стоит `ВСТАВИТЬ_...`, скрипты не грузятся);
- отслеживает события: `cta_click`, `form_start`, `form_submit`, `messenger_open`, `case_view`, `scroll_50`, `scroll_90` (видно в консоли браузера как `[analytics] ...`, пока не подключены реальные счётчики).

## 5. Публикация на Vercel

1. Залейте проект в GitHub/GitLab.
2. На https://vercel.com → **New Project** → выберите репозиторий.
3. Vercel сам определит Next.js — просто нажмите **Deploy**.
4. После деплоя обновите `siteConfig.seo.url` на реальный домен и задеплойте повторно (для корректных Open Graph/canonical).

Либо через CLI:
```bash
npm i -g vercel
vercel
```

## 6. Адаптивность

Сайт построен на Tailwind-брейкпоинтах (`sm`, `lg`) и проверен на сетке от 320px:
- 320×568, 375×667, 390×844, 430×932 — мобильные, одна колонка, бургер-меню, фиксированная CTA-кнопка снизу;
- 768×1024 — планшет, карточки в 2 колонки;
- 1440×900, 1920×1080 — десктоп, полная раскладка в 2–4 колонки.

Рекомендуется дополнительно проверить эти размеры вручную в DevTools после `npm run dev`, так как в этой среде нет браузера для автоматического скриншот-тестирования.

## 7. Структура проекта

```
app/
  layout.tsx        — метатеги, Open Graph, Schema.org, шрифты
  page.tsx           — сборка всех секций
  globals.css         — Tailwind + базовые стили
components/
  Header.tsx          — фиксированная шапка, бургер-меню
  Hero.tsx             — первый экран
  PainPoints.tsx       — блок "боли"
  WhatYouGet.tsx       — что входит в разбор + схема процесса
  BeforeAfter.tsx      — переключатель До/После + график
  Cases.tsx            — кейсы
  ProcessSteps.tsx     — 4 шага разбора
  About.tsx            — о специалисте + счётчики
  LeadForm.tsx         — форма записи
  FAQ.tsx              — аккордеон вопросов
  FinalCTA.tsx         — финальный экран
  Footer.tsx
  MobileStickyCta.tsx  — липкая CTA-кнопка на мобильных
  AnalyticsInit.tsx    — UTM, скролл-трекинг, Метрика/VK Pixel
  ui/
    Button.tsx         — кнопка с магнитным эффектом
    SectionHeading.tsx
    FloatingNotification.tsx
    GrowthChart.tsx     — анимированный SVG-график
    MoneyParticles.tsx  — декоративный фон (деньги, сетка, параллакс)
lib/
  config.ts            — ⭐ ВСЕ РЕДАКТИРУЕМЫЕ ДАННЫЕ ЗДЕСЬ
  analytics.ts
  messenger.ts
  hooks.ts
public/images/
  nikita.jpg            — фото специалиста
```

## 8. Важно про фотографии

По требованиям ТЗ все фото используют `object-fit: contain` внутри контейнеров с безопасными отступами — человек, руки и лицо не обрезаются ни на одном экране. Декоративные "деньги" на фоне — стилизованные SVG-иконки (банкноты/монеты), а не фотографии купюр, как и требовалось.
